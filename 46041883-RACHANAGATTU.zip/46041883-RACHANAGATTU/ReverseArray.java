package Lab2;
import java.util.Arrays;

public class ReverseArray {
  static void reverse(int a[],int n) {
	  int[] b=new int[n];
	  int j=n;
	  for(int i=0;i<n;i++) {
		  b[j-1]=a[i];
		  j=j-1;
	  }
	  System.out.println("After Reversing the Array");
	  for(int k=0;k<n;k++) {
		  System.out.println(b[k]);
	  }
	  Arrays.sort(a);
	  System.out.println("After Sorting the Array");
	  for(int p=0;p<a.length;p++) {
		  System.out.println(a[p]);
	  }
}
public static void main(String[] args) {
	int[] arr= {20,10,50,5,70,90};
	reverse(arr,arr.length);
}
}