package today;
public class New1 
{
   private String Cardetails;
   
   public New1(String Cardetails)
   {
	 this.Cardetails=Cardetails;   
   }

   public String getCardetails()
   {
	return Cardetails;
   }

   public void setCardetails(String Cardetails)
   {
	this.Cardetails= Cardetails;
   }
   
   public boolean equals(Object o)
   {
	   System.out.println("From Map");
	   if(o!=null && o instanceof New1)
	   {
		   String employeeId=((New1)o).getCardetails();
		   if(employeeId!=null && employeeId.equals(this.getCardetails()))
		   {
			   return true;
		   }
	   }
	return false;
   }
   
   public int hashCode()
   {
	   System.out.println("From Map...");
	   return this.Cardetails.hashCode();
   }
}