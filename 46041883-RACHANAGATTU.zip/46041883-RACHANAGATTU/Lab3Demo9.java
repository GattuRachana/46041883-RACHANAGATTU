package labs;

import java.util.Date;
class Lab3Demo9
{
 public static void main(String args[]) 
 {
  
  Date objDate = new Date();
  
  System.out.println(objDate.toString());
 }
}